# Intelligent Book Management System

## Overview

The Intelligent Book Management System is a robust API-driven application designed to manage a library of books and their associated reviews. It goes beyond basic book cataloging by integrating AI-powered features to generate book summaries and potentially provide personalized book recommendations. The system is built with a layered architecture, separating concerns into distinct layers like domain, application, and infrastructure. This approach promotes maintainability, testability, and scalability.

## Features

*   **Book Management:**
    *   Create, read, update, and delete book records.
    *   Retrieve lists of books with pagination.
    *   Store book information, including title, author, genre, year published, and summary.
*   **Review Management:**
    *   Add, retrieve, and manage user reviews for books.
    *   Associate reviews with specific books and users.
    *   Calculate average ratings for books based on reviews.
*   **AI-Powered Summaries:**
    *   Automatically generate summaries for books using a Large Language Model (LLM).
    *   Generate summaries for arbitrary text content.
    *   Generate review summaries.
*   **AI-Powered Recommendations (Placeholder):**
    *   An endpoint is provided for future implementation of a book recommendation engine.
*   **Robust Data Storage:**
    *   Utilizes PostgreSQL as the underlying database for persistent storage.
*   **Asynchronous Operations:**
    *   Leverages asynchronous programming for efficient handling of concurrent requests.
*   **API Documentation:**
    *   Built with FastAPI, which automatically generates OpenAPI documentation.
*   **Health Check:**
    *   A dedicated endpoint for verifying the API is up and running.

## Tech Stack

*   **Backend Framework:** FastAPI (for building the API)
*   **Database:** PostgreSQL (for data storage)
*   **ORM:** SQLAlchemy (for database interactions)
*   **Async Programming:** `asyncio` (for concurrency)
*   **LLM Integration:** (for generating summaries)
*   **Testing:** pytest (for testing)
*   **Dependency Management**: `pip` (for managing packages)
*   **Environment Management**: `.env` and `python-dotenv` (for managing environment variables)

## Application Setup

Here's how to set up and run the application:

1.  **Prerequisites:**
    *   Python 3.8+ installed.
    *   PostgreSQL database set up and running.
    *   pip installed.

2.  **Installation:**

    *   **Using pip:**
        ```bash
        git clone https://github.com/GpSinghJadon/books_app.git
        cd https://github.com/GpSinghJadon/books_app.git
        pip install -r requirements.txt
        ```

3.  **Environment Variables:**
    *   Create a `.env` file in the root project directory.
    *   Add the following variables, replacing the placeholders with your actual values:
        ```
        ASYNC_DATABASE_URL="postgresql+asyncpg://<db_user>:<db_password>@<db_host>:<db_port>/<db_name>"
        SYNC_DATABASE_URL="postgresql://<db_user>:<db_password>@<db_host>:<db_port>/<db_name>"
        HOST="0.0.0.0"
        PORT="8000"
        RELOAD="true" # set to false in production
        LOG_LEVEL="info" # or debug, warning, error
        SQLALCHEMY_ECHO="False"
        DB_POOL_SIZE="10"
        DB_MAX_OVERFLOW="20"
        DB_POOL_TIMEOUT="30"
        ```

4.  **Database Initialization:**
    *   The first time you run the app, it will create the database schema automatically.  If you need to drop and recreate the tables, you'll need to comment in the appropriate section in `database.py`. It's recommended that you use migrations for production systems (e.g., using Alembic).

5.  **Running the Application:**

    *   **Using pip:**
        ```bash
        uvicorn main:app --reload
        ```
    *   This starts the Uvicorn server. You can access the API documentation at `http://localhost:8000/docs`.

6.  **Testing**
    * using `pytest`
    ```bash
    pytest tests/
    ```

## API Documentation:
The API documentation is automatically generated using FastAPI's built-in OpenAPI documentation. You can access it at `http://localhost:8000/docs`.

## CI/CD Setup (AWS CodePipeline)

This project includes a basic configuration for setting up a Continuous Integration and Continuous Deployment (CI/CD) pipeline using AWS services.

1.  **`buildspec.yml`:**
    *   A `buildspec.yml` file is included in the root directory. This file defines the build commands and environment for AWS CodeBuild. It handles:
        *   Installing Python and project dependencies (`requirements.txt`).
        *   (Optional) Running linters and tests.
        *   Packaging the application artifacts needed for deployment.
    *   You may need to adjust the Python version or add specific build/test commands based on your exact requirements.

2.  **AWS CodePipeline Setup:**
    *   You can create a pipeline in the AWS Management Console (or using AWS CLI/CloudFormation/CDK).
    *   **Source Stage:** Connect the pipeline to your code repository (e.g., GitHub, AWS CodeCommit). Configure it to trigger the pipeline on code changes (e.g., pushes to the `main` branch).
    *   **Build Stage:**
        *   Configure this stage to use AWS CodeBuild.
        *   Create a CodeBuild project pointing to your repository.
        *   Ensure the build project uses the `buildspec.yml` file from the source code.
        *   Select an appropriate build environment (Operating System, Runtime matching the Python version in `buildspec.yml`).
        *   Grant necessary permissions (e.g., to access ECR if building Docker images).
    *   **Deploy Stage:**
        *   This stage is highly dependent on your target deployment environment.
        *   Configure deployment actions based on where you want to deploy the application (e.g., AWS Elastic Beanstalk, Amazon ECS, AWS App Runner, EC2 via CodeDeploy).
        *   The artifacts generated by the Build stage will be used as input for this stage.
        *   **Important:** Securely manage sensitive environment variables (like database credentials) using AWS Secrets Manager or Parameter Store, injecting them during the deployment phase or configuring them directly in the target service, rather than committing them to the repository.

This setup automates the process of building, testing (if configured), and deploying your application whenever changes are pushed to your repository.
