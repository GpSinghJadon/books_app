# schemas.py
# Pydantic models for data validation and serialization

from pydantic import BaseModel, Field
from typing import Optional, List

# --- Base Models ---
# Shared properties for books
class BookBase(BaseModel):
    title: str = Field(..., example="The Great Gatsby")
    author: str = Field(..., example="F. Scott Fitzgerald")
    genre: Optional[str] = Field(None, example="Fiction")
    year_published: Optional[int] = Field(None, example=1925)
    summary: Optional[str] = Field(None, example="A novel about the American dream.")

# Properties for creating a book (inherits from Base)
class BookCreate(BookBase):
    pass # Inherits all fields from BookBase

# Properties for updating a book (all fields optional)
class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    genre: Optional[str] = None
    year_published: Optional[int] = None
    summary: Optional[str] = None

# Properties for a book read from the database (includes ID)
class Book(BookBase):
    id: int = Field(..., example=1)

    class Config:
        orm_mode = True # Allows mapping from ORM objects

# --- Review Models ---
# Shared properties for reviews
class ReviewBase(BaseModel):
    user_id: int = Field(..., example=101)
    review_text: str = Field(..., example="A masterpiece of modern literature.")
    rating: int = Field(..., ge=1, le=5, example=5) # Rating between 1 and 5

# Properties for creating a review
class ReviewCreate(ReviewBase):
    pass # book_id will be provided by the path parameter

# Properties for a review read from the database (includes ID and book_id)
class Review(ReviewBase):
    id: int = Field(..., example=55)
    book_id: int = Field(..., example=1)

    class Config:
        orm_mode = True # Allows mapping from ORM objects

# --- AI Feature Models ---

# Model for requesting a summary generation
class SummaryRequest(BaseModel):
    text_content: str = Field(..., example="Provide the text you want summarized here...")

# Model for returning a generated summary
class GeneratedSummary(BaseModel):
    generated_summary: str = Field(..., example="This is the AI-generated summary.")

# Model for returning book summary and rating
class BookSummary(BaseModel):
    summary: Optional[str] = Field(None, example="A novel about the American dream.")
    average_rating: Optional[float] = Field(None, example=4.5)